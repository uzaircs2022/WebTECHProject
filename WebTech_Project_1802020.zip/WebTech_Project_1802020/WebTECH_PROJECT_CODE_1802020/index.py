from types import new_class
from flask import Flask
from flask import render_template
from flask import request
from flask import session
from flask import flash
from flask import redirect, url_for
from flask_mysqldb import MySQL

app = Flask(__name__)
app = Flask(__name__, template_folder="template")


app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'graphicStore'
mysql = MySQL(app)


@app.route('/')
def home():
   return render_template('Login.html')

@app.route('/homee')
def homee():
    return render_template('home.html')

@app.route('/animals')
def animal():
    return render_template('animals.html')

@app.route('/plants')
def plants():
    return render_template('plants.html')

@app.route('/vehicles')
def vehicle():
    return render_template('vehicles.html')

@app.route('/shapes')
def shapes():
    return render_template('shapes.html')

@app.route('/about')
def about():
    return render_template('about.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
     if request.method == 'POST':
        
        phoneNumber = request.form['id']
        password = request.form['password']

     
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM users WHERE phoneNumber = %s AND password = %s', (phoneNumber, password))
        acount = cursor.fetchone()
        if acount:
            return render_template('home.html')
        else:
            return render_template('Login.html')
     return render_template('Login.html')
    # try:
    #     if request.method == 'POST':
    #         ID = request.form['id']
    #         password = request.form['password']

    #         cur = mysql.connection.cursor()

    #         con = sql.connect("database.db")
    #         con.row_factory = sql.Row
    #         cur = con.cursor()
    #         cur.execute("select * from users where phoneNumber = %s",(ID))
    #         passw = cur.fetchone()
    #         PASSW = passw["password"]
    # except:
    #     con.rollback()
    # finally:
    #     if password == PASSW:
    #         return render_template('home.html')
    #     else:
    #         return render_template('Login.html')



@app.route('/list')
def list():
   con = mysql.connect("database.db")
   con.row_factory = mysql.Row
   
   cur = con.cursor()
   cur.execute("select * from users")
   
   rows = cur.fetchall(); 
   return render_template("list.html",rows = rows)



@app.route('/logout')
def logout():
    return redirect(url_for('login'))


@app.route('/Signup',methods=['GET','POST'])
def Signup():
    if request.method == 'POST':
        user=request.form
        name = user['name']
        phoneNumber = user['phonenumber']
        password = user['password']


        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO users VALUES (%s,%s,%s)",(name,phoneNumber,password))
        mysql.connection.commit()
        cur.close()
        return render_template('Login.html')
    return render_template('Signup.html')

if __name__ == '__main__':
    print("Check")
    app.run(debug = True)
    